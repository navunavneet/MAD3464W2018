/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class DAY3Interface {
 
    
    
    
    public static void main(String[] args){
    
        
        Addition op1 = new Addition();
    op1.display();
}
    Counting cn1 = new Counting():
    cn1.display();
    
    A a1 = new A();
    a1.display();
    a1.calcMultiplication();
}

interface Arithmetic{
    int n1 = 10;
    int n2 = 10;
    void display();
        }

class Addition implements Arithmetic{
   // int n1 = 20;
   // int n2 = 30;

    @Override
    public void display() {
    System.out.println(n1 + " + " + n2 + " = " + (n1+n2));
    
}
}
class Counting extends Addition{
    
}

interface multiplication extends Arithmetic{
    void calMultiplication();
}

class A implements multiplication{
    void display(){
        
    }
} 
    @Override  
public void display(){
System.out.println("n1 = " + n1 + " n2 = " + n2);
}

@Override
void calacMultiplication(){
System.out
}


class B implements  division and multiplication{ 
@Override
public void calcDivision(){

}
}