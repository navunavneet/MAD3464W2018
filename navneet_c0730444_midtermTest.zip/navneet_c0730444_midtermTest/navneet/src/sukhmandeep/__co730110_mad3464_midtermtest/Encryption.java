/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sukhmandeep.__co730110_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
public class Encryption {
    
    
  void encryption(String name){
        char c[]={};
        
        for(int i=1;i<=name.length();i++){
            if((i%2) == 0){
                c[i] = name.charAt(i);
                c[i] +=2;
                System.out.println(c);
            }
            else if((i%2) !=0){
                c[i] = name.charAt(i);
                c[i] +=1;
              
            }
            
            System.out.println(c);            
        }
          String str = new String(c);
           System.out.println(str); 
    }
    
    
    
    
}
