package test;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Batsman  extends Player {
    
    int noBowlsPlayed;
    int runsTaken [] = new int[6];
    double strikeRate;
    int totalRuns;
    int batingPoints;
      Scanner input = new Scanner(System.in);
    Batsman(){
       this.noBowlsPlayed = 0;
       for(int i =0; i<=6; i++){
           this.runsTaken[i]=0;
           
       }
        this.strikeRate =0.0;
        this.totalRuns =0;
        this.batingPoints =0;
        
    }
    
    Batsman(int noBowlsPlayed,int runsTaken, double strikeRate, int totalRuns, int batingPoints,String PlayerId, String PlayerName){
        super(PlayerId,PlayerName);
        this.noBowlsPlayed = 0;
        for(int i =0; i<=6; i++){
           this.runsTaken[i]=0;
           
       }
        
    this.strikeRate =strikeRate;
        this.totalRuns =totalRuns;
        this.batingPoints =batingPoints;
        
    }      
    void readData(){
        super.readData();
 
        System.out.println(" enter no of bowls played: " );
        this.noBowlsPlayed = input.nextInt();
         
  
        for(int i =0; i<7; i++){
        System.out.println("enter no of 1's taken:  ");
         
            this.runsTaken[0]=input.nextInt(); 
         
         System.out.println("enter no of 4's taken:  ");
        
            this.runsTaken[2]=input.nextInt(); 
            
        System.out.println("enter no of 6's taken:  ");
        
            this.runsTaken[5]=input.nextInt();
      break;
        }
         }
//   
    void calAvg(){
        this.totalRuns = (4*this.runsTaken[2])+(6*this.runsTaken[5]  + (runsTaken[0]));
        this.strikeRate = totalRuns/noBowlsPlayed;
                   
    }
    void calPoints(){
        int points;
        int pointsfour = 3*runsTaken[2];
        int pointsfor5 = 5*runsTaken[5];
        
        points = pointsfour + pointsfor5;
        this.batingPoints = points;
        super.displayData();
          System.out.println("no of bowls played:" + this.noBowlsPlayed + "\n no of runs taken:" +(this.runsTaken[0]+ 4*this.runsTaken[2] + 6*this.runsTaken[5])  + "\n strike rate : " + this.strikeRate);
         System.out.println(" total runs: " + this.totalRuns + "\nbating points: " + this.batingPoints);
          
    }
}