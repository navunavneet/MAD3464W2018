/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author macstudent
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
         
        Player player = new Player();
        
        String type1 = player.type();
 
        
        
      if(type1.equalsIgnoreCase("bowler")){ 
        
     Bowler bowler = new Bowler();
    
    bowler.readData();
    bowler.calAvg();
    bowler.calPoints();
   bowler.displayData();
      }
      else if(type1.equalsIgnoreCase("batsman")){
          
      }
     Batsman batsman = new Batsman();
     batsman.readData();
     batsman.calAvg();
     batsman.calPoints();
     batsman.displayData();
     
     
    }
    
}
